This is both sample and also a template for Ceyhun-Cizge Kurami.

Do not change 
- amsTurkish.sty
- Ceyhun.sty

Check pages directory.
- ceyhun-001-samplePage.tex is a sample LateX page.
- ceyhun-XXX.tex is the page that you are going to write and submit.
Note that related images are under images directory.
