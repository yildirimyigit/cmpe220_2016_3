
[X,Y] = meshgrid(-3:.1:3,-3:.1:3);

Z =4*X.^2+Y.^2;
P=zeros(61,61);
P(:,:)=9;


clip = find(Z > P);	
Z(clip) = 9;
mesh(X, Y, Z);


 hold on
   set(gca,'visible','off');
    lims = axis;
 axis([-3 3 -3 3 0 8])

plot3(-2:0,[0,0,0],[0,0,0],'black') % for x-axis
plot3(zeros(5,1),-4:0,zeros(5,1),'black')
plot3(zeros(10,1),zeros(10,1),1:10,'black')
hold on
 text(-2,0.5,0,'x');
  text(-0.2,-3.5,0,'y');
   text(-0.5,-0.1,7.5,'z');
   text(-0.5,-0.5,0,'0');

