% You can find comparisons of original pages with ones I created in this folder.

ceyhun-207
----------

\usepackage[turkish]{babel}
\renewcommand\turkishtablename{Cizelge}

\lhead{4. B�L�M}

% Image is created via inkscape and added to images folder in svg, eps and pdf format.

feyzioglu-62
------------

\usepackage{amssymb}

% 7.1.b.3 was divided into page 63, but I wrote it in page 62 and ended document.
