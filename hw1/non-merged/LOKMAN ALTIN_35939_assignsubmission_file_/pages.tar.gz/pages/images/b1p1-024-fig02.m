
%%
figure(2)
rectangle('Position',[1 2 9 6],'FaceColor','w')
set(gca, 'visible', 'off') 
%axis([0 10 0 10])
axis equal
t = linspace(0, 2*pi, 100);
cir = @(r,ctr) [r*cos(t)+ctr(1); r*sin(t)+ctr(2)];                      % Circle Function
c1 = cir(2, [4; 5]);
c2 = cir(2, [7; 5]);

in1 = find(inpolygon(c1(1,:), c1(2,:), c2(1,:), c2(2,:)));              % Circle #1 Points Inside Circle #2
in2 = find(inpolygon(c2(1,:), c2(2,:), c1(1,:), c1(2,:)));              % Circle #2 Points Inside Circle #1

[fillx,ix] = sort([c1(1,in1) c2(1,in2)]);                               % Sort Points
filly = [c1(2,in1) (c2(2,in2))];
filly = filly(ix);
hold on
plot(c1(1,:), c1(2,:),'color','black')
hold on
plot(c2(1,:), c2(2,:),'color','black')
hold on
% horizontal lines
x1=1.3;
x2=1.3;
y1=8;
y2=2;
for i=0:28
x=[x1,x2];
y=[y1,y2];

x1=x1+0.3;

x2=x2+0.3;
plot(x,y,'color','black');
end
% vertical lines
x1=1.0;
x2=10;
y1=2;
y2=2;
for i=0:20
x=[x1,x2];
y=[y1,y2];

y1=y1+0.3;

y2=y2+0.3;
plot(x,y,'color','black');
end
pos = [2 3 4 4];
rectangle('Position',pos,'Curvature',[1 1],'FaceColor','white');
pos = [5 3 4 4];
rectangle('Position',pos,'Curvature',[1 1],'FaceColor','white');

fill([fillx fliplr(fillx)], [filly fliplr(filly)], 'w', 'EdgeColor','none')
pos = [2 3 4 4];
rectangle('Position',pos,'Curvature',[1 1]);
pos = [5 3 4 4];
rectangle('Position',pos,'Curvature',[1 1]);

t1=text(2.2,6.8,'A');
t2=text(8.2,6.8,'B');
t3=text(9.5,8.2,'U');

t4=text(5,1.5,'A'' \cup B ''');
t4.Interpreter='tex';
t1.FontSize=16;
t2.FontSize=16;
t3.FontSize=16;
t4.FontSize=16;
t1.FontWeight='bold';
t2.FontWeight='bold';
t3.FontAngle='italic';
c1 = cir(2, [4; 5]);
c2 = cir(2, [7; 5]);
% find the circle line crosses
intercept=3.2;
for i=0:12
[xout,yout] = linecirc(0,intercept,7,5,2); % horizontal lines
plot(xout,yout,'color','black');
intercept=intercept+0.3;
end

intercept=2.2;
for i=0:12
[xout,yout] = linecirc(Inf,intercept,4,5,2); % horizontal lines
plot(xout,yout,'color','black');
intercept=intercept+0.3;
end
fill([fillx fliplr(fillx)], [filly fliplr(filly)], 'w', 'EdgeColor','none')
hold off
