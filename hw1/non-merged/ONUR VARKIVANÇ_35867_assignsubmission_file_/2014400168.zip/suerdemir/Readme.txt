=========================================ABOUT WRAPFIG=======================================

The page b1p1-23 contains a Venn diagram on the right side of the page. While converting this, 
I first placed the image on the right like the original, however this required "wrapfig" package 
(also mentioned in the footnotes). This implementation is saved in "b1p1-023 - wrapfig.tex".

Standard implementation with center alignment is contained in "b1p1-023.tex" file, however this 
one looks different from the original file. This second implementation does not require an 
additional package.