N = 100;
x = zeros(N, N);
y = zeros(N, N);
for i = 1 : N
    for j = 1 : N
        x(i, j) = 2 * (j - 1) / (N - 1);
        y(i, j) = 2 * (i - 1) / (N - 1);
        if(x(i, j) * x(i, j) + y(i, j) * y(i, j) < 1 || 4 < x(i, j) * x(i, j) + y(i, j) * y(i, j) || atan(y(i, j) / x(i, j)) < pi / 6)
            y(i, j) = 0;
            x(i, j) = 0;
        end
    end
end
region = plot(x, y, '.k');
axis([0, 2, 0, 2]);
axis('square');