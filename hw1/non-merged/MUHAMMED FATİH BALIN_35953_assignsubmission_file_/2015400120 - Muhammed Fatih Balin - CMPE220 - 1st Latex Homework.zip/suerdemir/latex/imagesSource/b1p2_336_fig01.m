N = 200;
x = zeros(N, N);
startingangle = pi/6;
endingangle = pi/3;
y = zeros(N, N);
startingradius = 0;
endingradius = 1;
for i = 1 : N
    for j = 1 : N
        x(i, j) = 2 * (j - 1) / (N - 1);
        y(i, j) = 2 * (i - 1) / (N - 1);
        if(x(i, j) * x(i, j) + y(i, j) * y(i, j) > 1 || atan(y(i, j) / x(i, j)) < pi / 6 || pi / 3 < atan(y(i, j) / x(i, j)))
            y(i, j) = 0;
            x(i, j) = 0;
        end
    end
end
region = plot(x, y, '.k');
axis([0, 1, 0, 1]);
axis('square');