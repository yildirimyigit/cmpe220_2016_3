theta = zeros(1, 6);
radius = zeros(1, 6);
radius1 = zeros(1, 100);
for i = 1:6
   theta(i) = (i - 1) * 2 * pi / 5 + pi/20;
   radius(i) = 2.^0.1;
end
for i = 1:100
   radius1(i) = 2.^0.1;
end
polarplot(theta, radius);
hold on;
polarplot(radius1);